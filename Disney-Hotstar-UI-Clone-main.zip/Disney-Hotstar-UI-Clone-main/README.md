# Disney-Hotstar-UI-Clone

my main reference in developing this UI is from youtube https://www.youtube.com/watch?v=ZeY9RicS2js
